import { GoogleGenAI, Type } from "@google/genai";
import { Coursebook } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function analyzeCoursebookImage(base64Data: string, mimeType: string, fileName?: string): Promise<Coursebook> {
  const model = "gemini-3-flash-preview";
  
  const prompt = `
    Analyze this coursebook content page. 
    Extract the didactic units, including their unit number/title, grammar items, vocabulary sets, and main topics.
    Return the data in a structured JSON format.
    ${fileName ? `NOTE: The coursebook title should be "${fileName}" if you cannot find a more specific one on the page.` : ''}
  `;

  const response = await ai.models.generateContent({
    model,
    contents: [
      {
        parts: [
          { text: prompt },
          {
            inlineData: {
              data: base64Data.split(',')[1] || base64Data,
              mimeType: mimeType
            }
          }
        ]
      }
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          level: { type: Type.STRING },
          publisher: { type: Type.STRING },
          units: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                unitNumber: { type: Type.STRING },
                title: { type: Type.STRING },
                grammar: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      item: { type: Type.STRING },
                      description: { type: Type.STRING }
                    },
                    required: ["item"]
                  }
                },
                vocabulary: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      topic: { type: Type.STRING },
                      items: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING }
                      }
                    },
                    required: ["topic", "items"]
                  }
                },
                topics: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING }
                }
              },
              required: ["unitNumber", "title", "grammar", "vocabulary", "topics"]
            }
          }
        },
        required: ["title", "units"]
      }
    }
  });

  const result = JSON.parse(response.text || "{}");
  return {
    id: crypto.randomUUID(),
    ...result
  };
}

export async function analyzeCoursebookExcel(jsonData: any): Promise<Coursebook[]> {
  const model = "gemini-3-flash-preview";
  
  const prompt = `
    Analyze this JSON data extracted from an Excel file containing multiple English coursebook syllabi.
    Each coursebook should have a title, level, and units with grammar, vocabulary, and topics.
    
    IMPORTANT: The coursebook title for each row or section should be taken from "Column A" (which is usually the first property in each object of the provided JSON).
    
    Return an array of coursebooks in the specified JSON format.
    
    Data:
    ${JSON.stringify(jsonData, null, 2)}
  `;

  const response = await ai.models.generateContent({
    model,
    contents: [{ parts: [{ text: prompt }] }],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            level: { type: Type.STRING },
            publisher: { type: Type.STRING },
            units: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  unitNumber: { type: Type.STRING },
                  title: { type: Type.STRING },
                  grammar: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        item: { type: Type.STRING },
                        description: { type: Type.STRING }
                      },
                      required: ["item"]
                    }
                  },
                  vocabulary: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        topic: { type: Type.STRING },
                        items: {
                          type: Type.ARRAY,
                          items: { type: Type.STRING }
                        }
                      },
                      required: ["topic", "items"]
                    }
                  },
                  topics: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                  }
                },
                required: ["unitNumber", "title", "grammar", "vocabulary", "topics"]
              }
            }
          },
          required: ["title", "units"]
        }
      }
    }
  });

  const results = JSON.parse(response.text || "[]");
  return results.map((result: any) => ({
    id: crypto.randomUUID(),
    ...result
  }));
}

export async function compareCoursebooks(coursebooks: Coursebook[]): Promise<string> {
  const model = "gemini-3.1-pro-preview"; // Use pro for complex reasoning
  
  const prompt = `
    Compare the following English coursebooks, focusing EXCLUSIVELY on grammar points:
    ${JSON.stringify(coursebooks, null, 2)}
    
    CRITICAL INSTRUCTIONS:
    1. Focus ONLY on grammar items. Do NOT include vocabulary themes, vocabulary sets, or general topics.
    2. When referencing a grammar item from a coursebook, you MUST provide the Unit number or title in which it is found (e.g., "[Book Title] - Unit 3: [Grammar Item]").
    3. Do NOT provide a suggested optimized syllabus (no Section 5).
    4. Use a clear Markdown format with tables or lists.

    Identify:
    1. Common grammar items across all or most books. For each item, list every book that contains it and the specific Unit where it appears.
    2. Unique grammar items found in only one specific book. Identify the book and the Unit for each.
    
    Provide a detailed comparative analysis of the grammar syllabi in Markdown format.
  `;

  const response = await ai.models.generateContent({
    model,
    contents: [{ parts: [{ text: prompt }] }]
  });

  return response.text || "No analysis generated.";
}

export async function compareWithBenchmark(benchmark: Coursebook, coursebooks: Coursebook[]): Promise<string> {
  const model = "gemini-3.1-pro-preview"; // Use pro for complex reasoning
  
  const prompt = `
    Analyze and compare the following English coursebooks against the designated Benchmark Syllabus, focusing EXCLUSIVELY on grammar points:
    
    BENCHMARK SYLLABUS:
    ${JSON.stringify(benchmark, null, 2)}
    
    COMPARED COURSEBOOKS:
    ${JSON.stringify(coursebooks, null, 2)}
    
    CRITICAL INSTRUCTIONS:
    1. Focus ONLY on grammar items. Do NOT include vocabulary themes, vocabulary sets, or general topics.
    2. When referencing any grammar item, always indicate the specific Unit number/title in which it is found in both the Benchmark and the compared books.
    3. For each compared coursebook, analyze:
       a. Alignment: How closely does the coursebook align with the Benchmark's progression and unit structure?
       b. Covered Grammar: Which benchmark grammar points are included in the coursebook (with specific unit numbers)?
       c. Gaps / Missing Grammar: Which benchmark grammar points are entirely missing from this coursebook?
       d. Extraneous Grammar: Which grammar points are covered in this coursebook that are NOT specified in the Benchmark Syllabus?
    4. Synthesize the findings into clear Markdown. Use comparison tables, percentage estimates of coverage, or side-by-side lists under dedicated markdown headers to make the insights clear and actionable for curriculum developers.

    Provide a highly detailed Benchmark Alignment and Gap Analysis in Markdown format.Do not include vocabulary items.
  `;

  const response = await ai.models.generateContent({
    model,
    contents: [{ parts: [{ text: prompt }] }]
  });

  return response.text || "No analysis generated.";
}

