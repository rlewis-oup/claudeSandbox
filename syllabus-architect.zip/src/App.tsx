import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BookOpen, 
  Plus, 
  Trash2, 
  BarChart3, 
  Loader2, 
  ChevronRight, 
  CheckCircle2,
  BookMarked,
  Layers,
  FileSpreadsheet,
  Image as ImageIcon,
  Download,
  FileText,
  FileCode
} from 'lucide-react';
import Markdown from 'react-markdown';
import { saveAs } from 'file-saver';
import { Document, Packer, Paragraph, TextRun } from 'docx';
import * as XLSX from 'xlsx';
import { FileUpload } from './components/FileUpload';
import { analyzeCoursebookImage, analyzeCoursebookExcel, compareCoursebooks, compareWithBenchmark } from './services/geminiService';
import { Coursebook } from './types';

export default function App() {
  const [coursebooks, setCoursebooks] = useState<Coursebook[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isAnalyzingBenchmark, setIsAnalyzingBenchmark] = useState(false);
  const [comparisonResult, setComparisonResult] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'upload' | 'comparison'>('upload');
  const [uploadMode, setUploadMode] = useState<'visual' | 'excel'>('visual');
  const [showExportOptions, setShowExportOptions] = useState(false);
  const [comparisonType, setComparisonType] = useState<'peer' | 'benchmark'>('peer');
  const [benchmarkSyllabus, setBenchmarkSyllabus] = useState<Coursebook | null>(null);

  const handleBenchmarkFile = async (files: { data: string | any; type: string; name: string }[]) => {
    setIsAnalyzingBenchmark(true);
    try {
      if (files.length > 0) {
        const file = files[0];
        const parsedBooks = await analyzeCoursebookExcel(file.data);
        if (parsedBooks && parsedBooks.length > 0) {
          // If the sheet had a title, great. Otherwise name it from Excel name minus extension
          const cleanTitle = file.name ? file.name.replace(/\.[^/.]+$/, "") : "Benchmark Standard";
          const firstBook = parsedBooks[0];
          setBenchmarkSyllabus({
            ...firstBook,
            title: firstBook.title || cleanTitle
          });
        }
      }
    } catch (error) {
      console.error("Failed to parse benchmark syllabus:", error);
    } finally {
      setIsAnalyzingBenchmark(false);
    }
  };

  const handleFilesSelected = async (files: { data: string | any; type: string; name: string }[]) => {
    setIsAnalyzing(true);
    try {
      if (uploadMode === 'excel') {
        // Excel files are processed one by one, but each can contain multiple books
        for (const file of files) {
          const newBooks = await analyzeCoursebookExcel(file.data);
          setCoursebooks(prev => [...prev, ...newBooks]);
        }
      } else {
        const newBooks = await Promise.all(
          files.map(file => analyzeCoursebookImage(file.data as string, file.type, file.name))
        );
        setCoursebooks(prev => [...prev, ...newBooks]);
      }
    } catch (error) {
      console.error("Analysis failed:", error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleCompare = async () => {
    if (comparisonType === 'benchmark') {
      if (!benchmarkSyllabus || coursebooks.length < 1) return;
      setIsAnalyzing(true);
      try {
        const result = await compareWithBenchmark(benchmarkSyllabus, coursebooks);
        setComparisonResult(result);
        setActiveTab('comparison');
      } catch (error) {
        console.error("Benchmark audit comparison failed:", error);
      } finally {
        setIsAnalyzing(false);
      }
    } else {
      if (coursebooks.length < 2) return;
      setIsAnalyzing(true);
      try {
        const result = await compareCoursebooks(coursebooks);
        setComparisonResult(result);
        setActiveTab('comparison');
      } catch (error) {
        console.error("Comparison failed:", error);
      } finally {
        setIsAnalyzing(false);
      }
    }
  };

  const exportToTxt = () => {
    if (!comparisonResult) return;
    const blob = new Blob([comparisonResult], { type: 'text/plain;charset=utf-8' });
    saveAs(blob, 'syllabus-analysis.txt');
    setShowExportOptions(false);
  };

  const exportToDocx = async () => {
    if (!comparisonResult) return;
    
    const doc = new Document({
      sections: [{
        properties: {},
        children: comparisonResult.split('\n').map(line => {
          return new Paragraph({
            children: [new TextRun(line)],
          });
        }),
      }],
    });

    const blob = await Packer.toBlob(doc);
    saveAs(blob, 'syllabus-analysis.docx');
    setShowExportOptions(false);
  };

  const exportToExcel = () => {
    if (coursebooks.length === 0) return;

    // Find max units to determine columns
    const maxUnits = Math.max(...coursebooks.map(b => b.units.length));
    
    // Prepare data for Excel
    const data = coursebooks.map(book => {
      const row: any = {
        'Course Name': book.title
      };
      
      book.units.forEach((unit, index) => {
        const grammarPoints = unit.grammar.map(g => g.item).join(', ');
        row[`Unit ${unit.unitNumber || index + 1} Grammar`] = grammarPoints;
      });
      
      return row;
    });

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Syllabus Comparison");
    
    const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    saveAs(blob, 'syllabus-comparison.xlsx');
    setShowExportOptions(false);
  };

  const removeCoursebook = (id: string) => {
    setCoursebooks(prev => prev.filter(b => b.id !== id));
  };

  return (
    <div className="min-h-screen bg-[#F5F5F4] text-zinc-900 font-sans">
      {/* Header */}
      <header className="border-b border-zinc-200 bg-white sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-zinc-900 rounded-lg flex items-center justify-center">
              <BookMarked className="w-5 h-5 text-white" />
            </div>
            <h1 className="font-semibold text-lg tracking-tight">Syllabus Architect</h1>
          </div>
          
          <nav className="flex gap-1 bg-zinc-100 p-1 rounded-xl">
            <button 
              onClick={() => setActiveTab('upload')}
              className={`px-4 py-1.5 text-sm font-medium rounded-lg transition-all ${activeTab === 'upload' ? 'bg-white shadow-sm text-zinc-900' : 'text-zinc-500 hover:text-zinc-700'}`}
            >
              Coursebooks
            </button>
            <button 
              onClick={() => setActiveTab('comparison')}
              disabled={!comparisonResult}
              className={`px-4 py-1.5 text-sm font-medium rounded-lg transition-all ${activeTab === 'comparison' ? 'bg-white shadow-sm text-zinc-900' : 'text-zinc-500 hover:text-zinc-700 disabled:opacity-50'}`}
            >
              Analysis
            </button>
          </nav>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-12">
        <AnimatePresence mode="wait">
          {activeTab === 'upload' ? (
            <motion.div 
              key="upload-view"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-12"
            >
              {/* Hero Section */}
              <div className="max-w-2xl">
                <h2 className="text-4xl font-light tracking-tight mb-4">
                  Build the perfect <span className="italic font-serif">syllabus</span>.
                </h2>
                <p className="text-zinc-500 text-lg">
                  Upload content pages from multiple English coursebooks. We'll extract the grammar to help you design a superior curriculum.
                </p>
              </div>

              {/* Comparative Objective */}
              <div className="bg-white p-8 rounded-2xl border border-zinc-200 shadow-sm space-y-6">
                <div className="space-y-2">
                  <h3 className="text-xl font-medium">Select Comparative Objective</h3>
                  <p className="text-zinc-500 text-sm">Choose how you want to evaluate and compare grammar syllabi.</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <button 
                    onClick={() => {
                      setComparisonType('peer');
                      setComparisonResult(null);
                    }}
                    className={`flex items-start gap-4 p-6 rounded-xl border-2 transition-all text-left ${comparisonType === 'peer' ? 'border-zinc-900 bg-zinc-50' : 'border-zinc-100 hover:border-zinc-200'}`}
                  >
                    <div className={`p-3 rounded-lg ${comparisonType === 'peer' ? 'bg-zinc-900 text-white' : 'bg-zinc-100 text-zinc-500'}`}>
                      <BarChart3 className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-zinc-900">Peer-to-Peer Cohort comparison</h4>
                      <p className="text-sm text-zinc-500">Cross-reference multiple coursebooks directly to evaluate general overlap, gaps, and unique coverages.</p>
                    </div>
                  </button>

                  <button 
                    onClick={() => {
                      setComparisonType('benchmark');
                      setComparisonResult(null);
                    }}
                    className={`flex items-start gap-4 p-6 rounded-xl border-2 transition-all text-left ${comparisonType === 'benchmark' ? 'border-amber-600 bg-amber-50/30' : 'border-zinc-100 hover:border-zinc-200'}`}
                  >
                    <div className={`p-3 rounded-lg ${comparisonType === 'benchmark' ? 'bg-amber-600 text-white' : 'bg-zinc-100 text-zinc-500'}`}>
                      <BookMarked className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-zinc-900">Benchmark Alignment Audit</h4>
                      <p className="text-sm text-zinc-500">Establish a master syllabus (via Excel) as the target standard, then audit third-party syllabi against it.</p>
                    </div>
                  </button>
                </div>
              </div>

              {/* Mode Selection */}
              <div className="bg-white p-8 rounded-2xl border border-zinc-200 shadow-sm space-y-6">
                <div className="space-y-2">
                  <h3 className="text-xl font-medium">How do you want to add target coursebooks?</h3>
                  <p className="text-zinc-500 text-sm">Choose your preferred input method for coursebooks under analysis.</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <button 
                    onClick={() => setUploadMode('visual')}
                    className={`flex items-start gap-4 p-6 rounded-xl border-2 transition-all text-left ${uploadMode === 'visual' ? 'border-zinc-900 bg-zinc-50' : 'border-zinc-100 hover:border-zinc-200'}`}
                  >
                    <div className={`p-3 rounded-lg ${uploadMode === 'visual' ? 'bg-zinc-900 text-white' : 'bg-zinc-100 text-zinc-500'}`}>
                      <ImageIcon className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-semibold">Visual Analysis</h4>
                      <p className="text-sm text-zinc-500">Upload photos or PDFs of content pages. Best for physical books.</p>
                    </div>
                  </button>

                  <button 
                    onClick={() => setUploadMode('excel')}
                    className={`flex items-start gap-4 p-6 rounded-xl border-2 transition-all text-left ${uploadMode === 'excel' ? 'border-emerald-600 bg-emerald-50' : 'border-zinc-100 hover:border-zinc-200'}`}
                  >
                    <div className={`p-3 rounded-lg ${uploadMode === 'excel' ? 'bg-emerald-600 text-white' : 'bg-zinc-100 text-zinc-500'}`}>
                      <FileSpreadsheet className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-semibold">Excel Import</h4>
                      <p className="text-sm text-zinc-500">Upload an Excel file containing multiple syllabi. Best for digital records.</p>
                    </div>
                  </button>
                </div>
              </div>

              {/* Upload Area */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-1 space-y-6">
                  {/* Master Benchmark Upload Block */}
                  {comparisonType === 'benchmark' && (
                    <div className="bg-white p-6 rounded-2xl border border-amber-200 shadow-sm space-y-4">
                      <h3 className="font-medium flex items-center gap-2 text-amber-900">
                        <BookMarked className="w-4 h-4 text-amber-600" /> Master Benchmark Syllabus
                      </h3>
                      
                      {benchmarkSyllabus ? (
                        <div className="p-4 bg-amber-50/50 rounded-xl border border-amber-100 flex items-start justify-between">
                          <div className="space-y-1">
                            <h4 className="font-semibold text-amber-950 text-sm truncate max-w-[180px]">{benchmarkSyllabus.title}</h4>
                            <span className="text-xs text-amber-800 block">
                              {benchmarkSyllabus.units?.length || 0} Units Loaded • Master Standard
                            </span>
                          </div>
                          <button 
                            onClick={() => setBenchmarkSyllabus(null)}
                            className="text-xs text-amber-700 hover:text-amber-900 font-medium underline"
                          >
                            Clear
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-3">
                          <p className="text-xs text-zinc-500">
                            Upload your curriculum standard as an Excel file (.xlsx, .xls) to serve as the master syllabus.
                          </p>
                          <FileUpload onFilesSelected={handleBenchmarkFile} mode="excel" />
                        </div>
                      )}
                    </div>
                  )}

                  <div className="bg-white p-6 rounded-2xl border border-zinc-200 shadow-sm">
                    <h3 className="font-medium mb-4 flex items-center gap-2">
                      <Plus className="w-4 h-4" /> Add {uploadMode === 'excel' ? 'Excel File' : 'Coursebook'}
                    </h3>
                    <FileUpload onFilesSelected={handleFilesSelected} mode={uploadMode} />
                  </div>

                  {/* Operational trigger buttons */}
                  {((comparisonType === 'peer' && coursebooks.length >= 2) || 
                    (comparisonType === 'benchmark' && benchmarkSyllabus !== null && coursebooks.length >= 1)) && (
                    <button 
                      onClick={handleCompare}
                      disabled={isAnalyzing}
                      className={`w-full text-white py-4 rounded-2xl font-medium flex items-center justify-center gap-2 transition-colors disabled:opacity-50 ${comparisonType === 'benchmark' ? 'bg-amber-600 hover:bg-amber-700' : 'bg-zinc-900 hover:bg-zinc-800'}`}
                    >
                      {isAnalyzing ? (
                        <Loader2 className="w-5 h-5 animate-spin" />
                      ) : (
                        <>
                          <BarChart3 className="w-5 h-5" />
                          {comparisonType === 'benchmark' ? 'Generate Benchmark Audit' : 'Generate Comparison'}
                        </>
                      )}
                    </button>
                  )}
                </div>

                <div className="lg:col-span-2">
                  <div className="bg-white rounded-2xl border border-zinc-200 shadow-sm overflow-hidden">
                    <div className="p-6 border-b border-zinc-100 flex items-center justify-between">
                      <h3 className="font-medium flex items-center gap-2">
                        <Layers className="w-4 h-4" /> Analyzed Books
                        <span className="ml-2 px-2 py-0.5 bg-zinc-100 text-zinc-500 text-xs rounded-full">
                          {coursebooks.length}
                        </span>
                      </h3>
                    </div>

                    <div className="divide-y divide-zinc-100">
                      {coursebooks.length === 0 ? (
                        <div className="p-12 text-center text-zinc-400 italic">
                          No coursebooks analyzed yet. Upload data to get started.
                        </div>
                      ) : (
                        coursebooks.map((book) => (
                          <div key={book.id} className="p-6 flex items-start justify-between hover:bg-zinc-50 transition-colors group">
                            <div className="space-y-1">
                              <h4 className="font-medium text-zinc-900">{book.title}</h4>
                              <div className="flex gap-4 text-xs text-zinc-500">
                                <span className="flex items-center gap-1">
                                  <BookOpen className="w-3 h-3" /> {book.units.length} Units
                                </span>
                                {book.level && <span>Level: {book.level}</span>}
                                {book.publisher && <span>Publisher: {book.publisher}</span>}
                              </div>
                            </div>
                            <button 
                              onClick={() => removeCoursebook(book.id)}
                              className="p-2 text-zinc-400 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div 
              key="comparison-view"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-8"
            >
              <div className="flex items-center justify-between">
                <h2 className="text-3xl font-light tracking-tight">Syllabus Analysis</h2>
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <button 
                      onClick={() => setShowExportOptions(!showExportOptions)}
                      className="bg-white border border-zinc-200 px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2 hover:bg-zinc-50 transition-colors"
                    >
                      <Download className="w-4 h-4" />
                      Export Analysis
                    </button>
                    
                    <AnimatePresence>
                      {showExportOptions && (
                        <motion.div 
                          initial={{ opacity: 0, y: 5 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: 5 }}
                          className="absolute right-0 mt-2 w-48 bg-white border border-zinc-200 rounded-xl shadow-lg z-20 overflow-hidden"
                        >
                          <button 
                            onClick={exportToDocx}
                            className="w-full px-4 py-3 text-left text-sm hover:bg-zinc-50 flex items-center gap-2 border-b border-zinc-100"
                          >
                            <FileText className="w-4 h-4 text-blue-600" />
                            Microsoft Word (.docx)
                          </button>
                          <button 
                            onClick={exportToTxt}
                            className="w-full px-4 py-3 text-left text-sm hover:bg-zinc-50 flex items-center gap-2"
                          >
                            <FileCode className="w-4 h-4 text-zinc-500" />
                            Plain Text (.txt)
                          </button>
                          <button 
                            onClick={exportToExcel}
                            className="w-full px-4 py-3 text-left text-sm hover:bg-zinc-50 flex items-center gap-2 border-t border-zinc-100"
                          >
                            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                            Excel Spreadsheet (.xlsx)
                          </button>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                  <button 
                    onClick={() => setActiveTab('upload')}
                    className="text-sm text-zinc-500 hover:text-zinc-900 flex items-center gap-1"
                  >
                    Back to Uploads
                  </button>
                </div>
              </div>

              <div className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm prose prose-zinc max-w-none">
                <div className="markdown-body">
                  <Markdown>{comparisonResult || ''}</Markdown>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Loading Overlay */}
      <AnimatePresence>
        {isAnalyzing && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-white/80 backdrop-blur-sm z-50 flex flex-col items-center justify-center"
          >
            <Loader2 className="w-12 h-12 text-zinc-900 animate-spin mb-4" />
            <p className="text-zinc-900 font-medium animate-pulse">
              {comparisonType === 'benchmark' && !benchmarkSyllabus 
                ? "Analyzing and modeling Master Benchmark Syllabus..." 
                : "Analyzing and comparing didactic grammar structures..."}
            </p>
            <p className="text-zinc-500 text-sm mt-2">
              Using Gemini AI structural comparison models
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
